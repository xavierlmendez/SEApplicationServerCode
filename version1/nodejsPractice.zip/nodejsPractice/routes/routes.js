import mysql from 'mysql';
import express from 'express';
//code legacy from tutorial https://www.asapdevelopers.com/build-a-react-native-login-app-with-node-js-backend/
//import { signup, login, isAuth } from '../controllers/auth.js';

const router = express.Router();

router.get('/responce', function (req, res) {
    
    // //configure the mysql connection object (delete password before upload)
    // var con = mysql.createConnection({
    //     host: '18.205.69.32',
    //     user: 'admin',
    //     password: '',
    //     database: "foodys",
    //     port: 3306
    // });
    
    // //legacy from an alternative method that utilizies connecting to the database through aws 
    //     // var RDS_HOSTNAME = '18.205.69.32';
    //     // var RDS_USERNAME= 'admin';
    //     // var RDS_PASSWORD= 'M100101s';
    //     // var RDS_PORT= 3306;
        
    
    // // .connect creates a connection using the previously defined connection object 
    // // and runs a function to catch errors an print err stack to console or output successful connection
    // con.connect(function(err){
    //     if (err){console.error('Database connection failed: ' + err.stack);
    //         throw err;
    //     }
    //     console.log('Connected to database.');
    // });
    
    // //sample query this would be called by a function that is listening for requests
    // //returns a json file

    // con.query('SELECT * FROM user;', function (err, rows, fields)
    // {
    //     if (err) console.log(err);
    //     else
    //     {
    //         console.log('query statement ran successfully');
    //     }

    // });
    
    // //closes the connection 
    // con.destroy;
    // console.log(resultArray);
    res.send("responce route works");



})
router.get('/public', (req, res, next) => {
    res.status(200).json({ message: "here is your public resource" });
});

// will match any other path
router.use('/', (req, res, next) => {
    res.status(404).json({error : "page not found"});
});

export default router;